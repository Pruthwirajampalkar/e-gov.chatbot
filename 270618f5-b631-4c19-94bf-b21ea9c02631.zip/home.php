<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
$username = htmlspecialchars($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>e-Governance Chatbot</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    body {
      scroll-behavior: smooth;
      background-image: url('Tecnología Educativa.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center center;
      background-attachment: fixed;
    }
    section {
      animation: fadeInUp 0.6s ease-out both;
    }
    @keyframes fadeInUp {
      0% { opacity: 0; transform: translateY(20px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    .chatbot-glow {
      box-shadow: 0 0 15px rgba(59, 130, 246, 0.6), 0 0 25px rgba(59, 130, 246, 0.3);
      animation: pulseGlow 2s infinite;
    }
    @keyframes pulseGlow {
      0%, 100% { box-shadow: 0 0 15px rgba(59, 130, 246, 0.6), 0 0 25px rgba(59, 130, 246, 0.3); }
      50% { box-shadow: 0 0 20px rgba(59, 130, 246, 0.9), 0 0 30px rgba(59, 130, 246, 0.4); }
    }
    .dark body {
      background-color: #1f2937;
      color: #e5e7eb;
    }
    .dark .bg-white { background-color: #1f2937; }
    .dark .bg-blue-700 { background-color: #3b82f6; }
    .dark .text-blue-700 { color: #60a5fa; }
    .dark .bg-gradient-to-r {
      background: linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(59, 130, 246, 0.3) 100%);
    }
  </style>
  <script>
    function openChatbot() {
      window.location.href = 'chatbot.php';
    }
    function toggleDarkMode() {
      document.body.classList.toggle("dark");
      localStorage.setItem("darkMode", document.body.classList.contains("dark") ? "enabled" : "disabled");
    }
    window.onload = () => {
      if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark");
      }
    };
  </script>
</head>
<body class="bg-gray-50 text-gray-800 font-sans">
  <header id="navbar" class="bg-white fixed top-0 left-0 w-full z-50 shadow">
    <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
      <h1 class="text-2xl font-bold text-blue-700">e-Governance Chatbot</h1>
      <div class="flex items-center gap-4">
        <span class="text-gray-600">Welcome, <?php echo $username; ?>!</span>
        <a href="logout.php" class="text-red-600 hover:underline">Logout</a>
        <button onclick="toggleDarkMode()" class="text-gray-600 hover:underline">🌙</button>
      </div>
    </div>
  </header>

  <section class="bg-gradient-to-r from-blue-100 via-white to-blue-100 py-24 mt-16">
    <div class="max-w-4xl mx-auto px-4 text-center">
      <h2 class="text-4xl font-bold text-blue-800 mb-4">Your Digital Government Assistant</h2>
      <p class="text-lg text-blue-700 mb-6">Access public services, ask questions, and get instant support — all in one place.</p>
      <div class="space-x-4">
        <a href="services.php" class="bg-white border border-blue-700 text-blue-700 px-6 py-2 rounded hover:bg-blue-50">Explore Services</a>
        <button onclick="openChatbot()" class="bg-blue-700 text-white px-6 py-2 rounded hover:bg-blue-800">Open Chatbot</button>
        <a href="appointments.php" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700">Appointments</a>
        <a href="notifications.php" class="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700">Notifications</a>
        <a href="grievances.php" class="bg-pink-600 text-white px-6 py-2 rounded hover:bg-pink-700">Grievances</a>
        <a href="contact.php" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 mt-2 inline-block">Contact Us</a>
        <a href="feedback.php" class="bg-yellow-600 text-white px-6 py-2 rounded hover:bg-yellow-700 mt-2 inline-block">Feedback</a>
      </div>
    </div>
  </section>

  <!-- About Section -->
  <section class="bg-white py-24">
    <div class="max-w-4xl mx-auto px-4 text-center">
      <h2 class="text-3xl font-bold text-blue-800 mb-6">About Us</h2>
      <p class="text-lg text-gray-700 mb-4">The e-Governance Chatbot is a digital assistant designed to simplify access to government services. Our aim is to provide a user-friendly platform where citizens can easily get the information they need about public services, apply for government schemes, and receive timely assistance.</p>
      <p class="text-lg text-gray-700">Our chatbot is equipped to answer frequently asked questions, provide guidance on various procedures, and make government services more accessible to the public. We believe in enhancing transparency, efficiency, and user engagement through the power of technology.</p>
    </div>
  </section>

  <button onclick="openChatbot()" class="chatbot-glow fixed bottom-6 right-6 bg-blue-700 text-white px-5 py-3 rounded-full shadow-lg hover:scale-105">💬 Chatbot</button>

  <footer class="bg-gray-100 pt-10 pb-6 text-gray-700 bg-opacity-90">
    <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-sm text-center md:text-left">
      <div>
        <h4 class="font-semibold text-blue-800 mb-2">Follow Us</h4>
        <ul class="space-y-1">
          <li><a href="#" class="hover:underline text-blue-600">Facebook</a></li>
          <li><a href="#" class="hover:underline text-blue-600">Twitter</a></li>
          <li><a href="#" class="hover:underline text-blue-600">Instagram</a></li>
          <li><a href="#" class="hover:underline text-blue-600">LinkedIn</a></li>
        </ul>
      </div>
      <div>
        <h4 class="font-semibold text-blue-800 mb-2">Useful Links</h4>
        <ul class="space-y-1">
          <li><a href="#" class="hover:underline text-blue-600">National Portal</a></li>
          <li><a href="#" class="hover:underline text-blue-600">UIDAI</a></li>
          <li><a href="#" class="hover:underline text-blue-600">Income Tax</a></li>
        </ul>
      </div>
      <div class="text-center md:text-right">
        &copy; 2025 e-Governance Chatbot<br>All rights reserved.
      </div>
    </div>
  </footer>
</body>
</html>
