<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
$username = htmlspecialchars($_SESSION['username']);
?>

<!DOCTYPE html> 
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Services</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #e3f4f6;
      margin: 0;
      padding: 20px;
    }

    header {
      background-color: #ffffff;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .header-left h1 {
      margin: 0;
      color: #c13e3e;
    }

    .header-right {
      font-size: 16px;
      color: #333;
    }

    .header-right a {
      color: red;
      text-decoration: none;
      margin-left: 10px;
    }

    h2 {
      text-align: center;
      color: #045b62;
      margin: 30px 0 10px;
    }

    #searchInput {
      display: block;
      margin: 0 auto 20px auto;
      padding: 10px;
      width: 80%;
      max-width: 500px;
      border: 2px solid #009ec1;
      border-radius: 5px;
      font-size: 16px;
    }

    .grid-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 15px;
      padding: 20px;
    }

    .card {
      background-color: white;
      border: 2px solid #009ec1;
      border-radius: 5px;
      padding: 20px;
      box-shadow: 0px 0px 5px rgba(0,0,0,0.2);
    }

    .card h3 {
      margin-top: 0;
      color: #00748f;
    }

    .top-btn {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #00bcd4;
      color: white;
      padding: 10px;
      border-radius: 50%;
      text-decoration: none;
      font-size: 18px;
    }

    footer {
      text-align: center;
      font-size: 14px;
      margin-top: 40px;
      color: #555;
    }
  </style>

  <script>
    function filterServices() {
      let input = document.getElementById('searchInput').value.toLowerCase();
      let cards = document.getElementsByClassName('card');

      for (let card of cards) {
        let title = card.getElementsByTagName('h3')[0].innerText.toLowerCase();
        let text = card.getElementsByTagName('p')[0].innerText.toLowerCase();
        card.style.display = (title.includes(input) || text.includes(input)) ? "block" : "none";
      }
    }
  </script>
</head>
<body>

<header>
  <div class="header-left">
    <h1>All Government Services</h1>
  </div>
  <div class="header-right">
    Welcome, <?php echo $username; ?>!
    <a href="logout.php">Logout</a>
  </div>
</header>

<h2>Explore Topics and Schemes</h2>
<input type="text" id="searchInput" onkeyup="filterServices()" placeholder="Search for a service...">

<div class="grid-container">
  <?php
  $services = [
    ["The India and its government", "Learn about Indian laws, history, and more. Buy government property. Contact elected officials and federal agencies.", "india-government"],
    ["Complaints", "File complaints involving government agencies, telemarketers, products and services, travel, housing, and banking.", "complaints"],
    ["Disability services", "Find government benefits and programs for people with disabilities and their families.", "disability-services"],
    ["Disasters and emergencies", "Learn about disaster relief and find government benefits for other emergencies.", "disasters-emergencies"],
    ["Education", "Learn about Federal Student Aid and studying in the U.S. Find early intervention, special education, and Head Start programs.", "education"],
    ["Government benefits", "Find government programs that may help pay for food, housing, health care, and more.", "government-benefits"],
    ["Health", "Get information about health insurance, various health conditions, and help with medical bills.", "health"],
    ["Housing help", "Learn about rental and buyer assistance programs. Find emergency housing and avoid eviction.", "housing-help"],
    ["Immigration and Indian citizenship", "Learn about Indian residency, Green Cards, citizenship requirements, and related topics.", "immigration-citizenship"],
    ["Jobs, labor laws, and unemployment", "Get resources for finding a job. Learn about unemployment insurance and important labor laws.", "jobs-labor"],
    ["Laws and legal issues", "Learn how to replace vital records, get child support enforcement, find legal help, and more.", "legal-issues"],
    ["Military and veterans", "Learn how to join the military and find benefits and services as a member or veteran.", "military-veterans"],
    ["Vehicle Services", "Apply for driving license, registration, challan status.", "vehicle-services"],
    ["LPG Subsidy", "Check subsidy status, book cylinders, link Aadhaar.", "lpg-subsidy"],
    ["Digital India Services", "Access DigiLocker, UMANG app, and more.", "digital-india"],
    ["PM Kisan Samman Nidhi", "₹6,000/year to small & marginal farmers.", "pm-kisan-samman"],
    ["Ayushman Bharat Yojana", "Health insurance of ₹5 lakh/year.", "ayushman-bharat"],
    ["PM Ujjwala Yojana", "Free LPG for below poverty line families.", "pm-ujjwala"],
    ["PM SVANidhi Scheme", "Working capital loans to street vendors.", "pm-svanidhi"],
    ["Election Services", "Voter ID registration, corrections, status check.", "election-services"],
    ["Education Services", "Scholarships, student loans, academic aid.", "education-services"]
  ];

  foreach ($services as $service) {
    echo "<div class='card'>";
    echo "<a href='service_details.php?service={$service[2]}'>";
    echo "<h3>{$service[0]}</h3>";
    echo "<p>{$service[1]}</p>";
    echo "</a>";
    echo "</div>";
  }
  ?>
</div>

<a href="#top" class="top-btn">↑</a>

<footer>
  &copy; 2025 e-Governance Chatbot. All rights reserved.
</footer>

</body>
</html>
